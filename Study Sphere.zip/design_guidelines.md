# AI Study Buddy - Design Guidelines

## Design Approach: Productivity System with Academic Focus

**Selected Approach:** Design System inspired by Linear + Notion
**Justification:** Student-focused productivity tool requiring clarity, efficiency, and organization. Drawing from Linear's clean typography and Notion's content organization patterns while adding academic-friendly touches.

---

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 224 71% 50% (Trust-inspiring blue for primary actions)
- Background Base: 0 0% 100% (Pure white)
- Background Secondary: 220 13% 96% (Subtle gray for cards/sections)
- Text Primary: 222 47% 11% (Near-black for readability)
- Text Secondary: 215 14% 45% (Muted for supporting text)
- Success: 142 76% 36% (Quiz correct answers, completion states)
- Border: 214 32% 91% (Subtle separators)

**Dark Mode:**
- Primary: 217 91% 60% (Brighter blue for dark backgrounds)
- Background Base: 222 47% 11% (Deep navy-black)
- Background Secondary: 217 33% 17% (Elevated surfaces)
- Text Primary: 210 20% 98% (High contrast white)
- Text Secondary: 215 20% 65% (Reduced contrast for hierarchy)
- Success: 142 71% 45% (Adjusted for dark mode)
- Border: 217 33% 24% (Visible but subtle)

### B. Typography

**Font Families:**
- Primary: 'Inter' (body text, UI elements) - via Google Fonts
- Display: 'Plus Jakarta Sans' (headings, hero) - via Google Fonts

**Scale:**
- Hero Heading: text-5xl md:text-7xl font-bold tracking-tight
- Section Heading: text-3xl md:text-4xl font-semibold
- Card Heading: text-xl font-semibold
- Body Large: text-lg leading-relaxed
- Body: text-base leading-relaxed
- Caption: text-sm text-secondary

### C. Layout System

**Spacing Primitives:** Tailwind units of 3, 4, 6, 8, 12, 16, 20, 24
- Component padding: p-6 or p-8
- Section spacing: py-16 md:py-24
- Card gaps: gap-6 or gap-8
- Element margins: mb-6, mt-8, etc.

**Grid System:**
- Container: max-w-7xl mx-auto px-4 sm:px-6 lg:px-8
- Dashboard: 2-column on md+ (sidebar + main content)
- Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6

### D. Component Library

**Navigation:**
- Top navbar: Sticky, backdrop-blur-lg bg-white/80 dark:bg-slate-900/80
- Logo + Upload CTA on right, responsive hamburger on mobile
- Breadcrumb navigation for topic drill-down

**Upload Zone:**
- Large drag-drop area with dashed border-2 border-dashed
- File icons using Heroicons (document-text, arrow-up-tray)
- Accepted formats badge: "PDF, TXT, DOCX"
- Progress bar during upload/processing

**Dashboard Cards:**
- Elevated: bg-white dark:bg-slate-800 shadow-sm hover:shadow-md transition
- Rounded-xl borders with subtle border-slate-200
- Topic badge in top-right corner
- Action buttons: View Summary, Study Flashcards, Take Quiz

**Summary Display:**
- Clean typography-focused layout, max-w-3xl for readability
- Topic headings with text-2xl font-semibold mb-4
- Bullet points with custom • markers, text-slate-600
- Collapsible sections for long summaries

**Flashcard Interface:**
- Card flip animation (transform rotate-y)
- Large card: min-h-[400px] with centered text
- Navigation arrows on sides (chevron-left, chevron-right icons)
- Progress indicator: "Card 3/15" at bottom
- "Know it" / "Study again" buttons below card

**Quiz Component:**
- Question number and progress bar at top
- Multiple choice: Radio buttons with hover:bg-slate-50 states
- Selected state: bg-primary-50 border-primary-500
- Submit button reveals correct/incorrect with color coding
- Score summary card at end with percentage circle chart

**Data Displays:**
- Study streak calendar: Grid of small squares (GitHub-style)
- Topic tags: Pill-shaped badges with bg-slate-100 text-slate-700
- Statistics cards: Large number display with icon and label

### E. Animations

**Minimal & Purposeful:**
- Card hover: hover:shadow-lg transition-shadow duration-200
- Button interactions: Built-in Tailwind transitions
- Page transitions: Fade-in content with opacity and translate
- Loading states: Subtle pulse animation on skeleton screens
- NO: Complex scroll animations, parallax, or decorative motion

---

## Page-Specific Layouts

### Landing/Hero Page (Marketing)
**Hero Section (80vh):**
- Split layout: Left 60% = Content, Right 40% = Image
- Headline: "Transform Your Study Materials into Interactive Learning"
- Subheading: "Upload PDFs → Get Summaries, Flashcards & Quizzes"
- CTA: Primary "Get Started Free" + outline "Watch Demo"
- Hero image: Illustration of student with floating study cards/books (placeholder: unsplash study/learning theme)

**Features Section (3-column grid):**
- Icon + heading + description cards
- Icons: Heroicons (document-text, lightning-bolt, academic-cap)
- Features: Smart Summaries, Instant Flashcards, AI-Powered Quizzes

**How It Works (3 steps, horizontal flow):**
- Number badges (1, 2, 3) with connecting lines
- Step cards: Upload → Process → Study
- Background: Subtle gradient bg-gradient-to-br from-slate-50 to-blue-50

**Social Proof:**
- 2-column testimonial cards with student photos (placeholder avatars)
- Stats row: "10K+ PDFs Processed" | "50K+ Flashcards Created"

**Final CTA Section:**
- Centered content, max-w-2xl
- Heading: "Ready to Study Smarter?"
- Primary CTA button, large and prominent

### Dashboard (Application)
**Layout:**
- Left sidebar: Navigation (Dashboard, My Materials, Study Sessions, Settings)
- Main area: Grid of recent study materials as cards
- Top: Search bar + "Upload New Material" button
- Empty state: Upload prompt with large icon if no materials

**Material Detail View:**
- Tabs: Summary | Flashcards | Quiz
- Sticky tab navigation at top
- Content area with appropriate component for each tab
- Sidebar: Material metadata (upload date, topic, file size)

---

## Images

**Hero Image (Required):**
- Location: Landing page hero section, right side
- Description: Modern illustration or photo of a student studying with digital elements (floating notes, highlighted text, quiz bubbles). Clean, optimistic, tech-forward aesthetic
- Style: Bright, friendly, minimal with primary blue accent colors
- Source: Unsplash search "student learning technology" or custom illustration

**Feature Section (3 images):**
- Summary preview screenshot: Clean document with highlighted sections
- Flashcard preview: Card flip animation mid-state
- Quiz interface: Multiple choice question with colorful UI

**Testimonial Section:**
- Student avatar placeholders: Diverse, friendly headshots
- Style: Circular crops, consistent sizing

**Dashboard Empty State:**
- Illustration: Upload cloud with document icons floating up
- Style: Minimal line art in primary blue color

---

## Quality Standards

- **Consistency:** Maintain 8px spacing grid, consistent border-radius (rounded-lg, rounded-xl)
- **Accessibility:** WCAG AA contrast ratios, focus states on all interactive elements
- **Responsiveness:** Mobile-first approach, test breakpoints at sm (640px), md (768px), lg (1024px)
- **Performance:** Use Heroicons CDN, optimize image loading with lazy loading
- **Polish:** Consistent shadow elevation system (shadow-sm, shadow-md, shadow-lg), smooth micro-interactions