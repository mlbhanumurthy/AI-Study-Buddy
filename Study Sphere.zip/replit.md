# AI Study Buddy - Smart Learning Platform

## Overview
AI Study Buddy is an intelligent learning platform that transforms study materials (PDFs and lecture notes) into interactive learning content using Google Gemini AI. Built for the AI Learnify Hackathon, this application helps students study more efficiently by automatically generating:

- **Topic-wise Summaries**: AI extracts key concepts and organizes them into digestible topics
- **Flashcards**: Automatically created question/answer pairs for memory recall
- **Quiz Questions**: Multiple-choice quizzes with explanations for self-assessment

## Current State
The MVP is complete and fully functional with:
- ✅ File upload system with drag & drop support (PDF/TXT)
- ✅ AI-powered content generation using Google Gemini 2.5 Flash
- ✅ Beautiful, responsive UI with dark mode support
- ✅ Real-time polling for AI-generated content
- ✅ Flashcard system with 3D flip animation
- ✅ Interactive quiz with scoring and explanations
- ✅ Background processing for non-blocking UX

## Project Architecture

### Tech Stack
**Frontend:**
- React with TypeScript
- Wouter for routing
- TanStack Query for data fetching
- Tailwind CSS + Shadcn UI components
- Vite for build tooling

**Backend:**
- Express.js server
- Google Gemini AI API integration
- Multer for file uploads
- pdf-parse for PDF text extraction
- In-memory storage (MemStorage)

### Key Design Patterns
1. **Schema-First Development**: All data models defined in `shared/schema.ts` for type safety
2. **Background Processing**: Upload returns immediately, AI generation happens asynchronously
3. **Polling for Updates**: Frontend auto-refetches every 2s until AI content is ready
4. **Parallel AI Generation**: Summaries, flashcards, and quizzes generated concurrently

### Data Flow
1. User uploads PDF/TXT file
2. Server extracts text content and creates material record
3. Material ID returned immediately to frontend
4. Backend generates AI content in background (parallel):
   - Summary with topic extraction
   - Flashcards (8-12 cards)
   - Quiz questions (6-10 questions)
5. Frontend polls and displays content as it becomes available

## Project Structure
```
├── client/
│   ├── src/
│   │   ├── pages/          # Main application pages
│   │   │   ├── home.tsx           # Landing page
│   │   │   ├── dashboard.tsx      # Materials dashboard
│   │   │   └── material-detail.tsx # View summaries/flashcards/quizzes
│   │   ├── components/     # Reusable components
│   │   │   ├── upload-dialog.tsx  # File upload UI
│   │   │   ├── summary-view.tsx   # Display AI summaries
│   │   │   ├── flashcard-view.tsx # 3D flip flashcards
│   │   │   ├── quiz-view.tsx      # Interactive quiz
│   │   │   ├── theme-provider.tsx # Dark mode support
│   │   │   └── theme-toggle.tsx   # Theme switcher
│   │   └── App.tsx         # Main app with routing
│   └── index.html          # HTML entry point with SEO meta tags
├── server/
│   ├── routes.ts           # API endpoints
│   ├── storage.ts          # In-memory data storage
│   └── gemini.ts          # Gemini AI integration
├── shared/
│   └── schema.ts          # Shared TypeScript types and schemas
└── design_guidelines.md   # Complete design system documentation
```

## API Endpoints

### Materials
- `GET /api/materials` - Get all uploaded materials
- `GET /api/materials/:id` - Get specific material
- `POST /api/upload` - Upload and process new file

### AI Content
- `GET /api/summaries/:materialId` - Get AI-generated summary
- `GET /api/flashcards/:materialId` - Get flashcard set
- `GET /api/quizzes/:materialId` - Get quiz questions

### System
- `GET /api/status` - Check Gemini API key configuration

## Environment Variables
- `GEMINI_API_KEY` - Google Gemini API key (required)
- `SESSION_SECRET` - Session encryption key (auto-configured)

## Recent Changes

### 2024-10-12: MVP Implementation
- Implemented complete schema for materials, summaries, flashcards, and quizzes
- Built all frontend components with exceptional visual polish
- Integrated Google Gemini AI for content generation
- Added background processing with polling for seamless UX
- Implemented 3D flip animation for flashcards
- Added API key validation with clear error messaging
- Tested and validated complete user journey

## Design System
The application follows a professional design system inspired by Linear and Notion:
- **Color Palette**: Trust-inspiring blue primary, semantic colors for success/error
- **Typography**: Inter for body, Plus Jakarta Sans for headings
- **Spacing**: Consistent 8px grid system
- **Components**: Shadcn UI with custom theme tokens
- **Interactions**: Subtle hover elevations, smooth transitions
- **Dark Mode**: Full support with optimized contrast

See `design_guidelines.md` for complete design specifications.

## User Preferences
- None specified yet

## Known Limitations
- In-memory storage (data resets on server restart)
- PDF parsing may struggle with scanned/image-based PDFs
- Gemini API free tier rate limits apply
- No user authentication (single-user experience)

## Future Enhancements (Post-MVP)
- User accounts with persistent storage
- Spaced repetition algorithm for flashcards
- Performance analytics and progress tracking
- Collaborative study groups
- Support for more file formats (DOCX, PPT, images with OCR)
- Export functionality for summaries and flashcards
